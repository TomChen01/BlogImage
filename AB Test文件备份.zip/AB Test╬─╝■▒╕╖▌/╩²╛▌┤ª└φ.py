import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from statsmodels.stats.proportion import proportions_ztest

# 1. 读取 Excel 文件
df = pd.read_excel("Cleaned_AB_Test_Data.xlsx")

# 2. 中文列 → 英文列映射
column_mapping = {
    '日期': 'Date',
    '组别': 'Group',
    '曝光量': 'Impressions',
    '点击量': 'Clicks',
    'CTR': 'CTR',
    '广告单': 'Ad_Orders',
    '自然单': 'Organic_Orders',
    '总单量': 'Total_Orders',
    'CVR': 'CVR',
    '广告单占比': 'Ad_Order_Ratio'
}
df.rename(columns=column_mapping, inplace=True)

# 3. 填充合并单元格缺失的日期
df["Date"] = df["Date"].fillna(method="ffill")
df["Date"] = pd.to_datetime(df["Date"])

# 4. 转换列类型（如必要）
df["Group"] = df["Group"].astype(str)
df = df.sort_values(by=["Date", "Group"])

# 5. 若未提供转化率列，自动生成
if 'CVR' not in df.columns or df['CVR'].isnull().any():
    df['CVR'] = np.where(df['Clicks'] > 0, (df['Total_Orders'] / df['Clicks']) * 100, 0)

# 6. 总结汇总数据
summary = df.groupby('Group').agg(
    Total_Clicks=('Clicks', 'sum'),
    Total_Orders=('Total_Orders', 'sum')
)
summary["Overall_CVR (%)"] = round(summary["Total_Orders"] / summary["Total_Clicks"] * 100, 2)

# 打印汇总结果
print("--- A/B 转化率汇总 ---")
print(summary)

# 7. Z检验（双尾比例检验）
print("--- Z 检验结果 ---")
count = summary["Total_Orders"].values
nobs = summary["Total_Clicks"].values

z_stat, p_value = proportions_ztest(count=count, nobs=nobs, alternative='two-sided')
print(f"Z-statistic = {z_stat:.4f}")
print(f"P-value = {p_value:.4f}")

alpha = 0.05
if p_value < alpha:
    print(f"显著性成立（p < {alpha}）：主图更新对转化率提升有显著影响。")
else:
    print(f"不显著（p ≥ {alpha}）：转化率提升可能是偶然因素。")

# 8. 可视化：每日 CVR、CTR 折线图
sns.set(style="whitegrid")

# 转化率图
plt.figure(figsize=(14, 7))
sns.lineplot(data=df, x="Date", y="CVR", hue="Group", marker="o", palette="Set1")
plt.title("Daily CVR: Group A vs Group B", fontsize=16)
plt.xlabel("Date", fontsize=10)
plt.ylabel("CVR (%)", fontsize=10)
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# 点击率图（如有 CTR 列）
if 'CTR' in df.columns:
    plt.figure(figsize=(14, 7))
    sns.lineplot(data=df, x="Date", y="CTR", hue="Group", marker="o", palette="Set2")
    plt.title("Daily CTR: Group A vs Group B", fontsize=16)
    plt.xlabel("Date", fontsize=10)
    plt.ylabel("CTR (%)", fontsize=10)
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()
