# A/B Test 数据清理代码汇总

import pandas as pd

# 读取文件
df = pd.read_excel("AB_Test_Data_2025-06-10_to_2025-06-24.xlsx")
print(df.head())

# 基础清洗：检查null，重复
print("null值数:",df.isnull().sum())
df = df.dropna() # 删除null行

print("重复行数:", df.duplicated().sum())
df = df.drop_duplicates() # 删除重复行

# 创建新指标
df["广告单占比"] = round(df["广告单"] / df["总单量"] * 100, 2)

df.to_excel("Cleaned_AB_Test_Data.xlsx", index=False)